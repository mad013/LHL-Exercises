class Destroyer < Ship

  def initialize
    super(length=4, max_shots=4)   
  end

end
