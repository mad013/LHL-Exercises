class Cruiser < Ship

  def initialize
    super(length=2, max_shots=4)
  end 

end
